Fixes Issue # (If it doesn't fix an issue then delete this line)

Features Added:
- Plugin Name (Add links if possible too)

Reasoning:
List why the feature is needed

Other:
Anything else relevant goes here
