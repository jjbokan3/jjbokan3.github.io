return { {
    "github/copilot.vim",
    event = "VeryLazy",
    autoStart = true,
  }, }


